/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_reviewanalyzer_free: (a: number, b: number) => void;
export const reviewanalyzer_analyze_diff: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
export const reviewanalyzer_analyze_diff_chunked: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
export const reviewanalyzer_new: (a: number, b: number, c: number, d: number, e: number) => void;
export const __wbindgen_export: (a: number, b: number, c: number) => void;
export const __wbindgen_export2: (a: number) => void;
export const __wbindgen_export3: (a: number, b: number) => number;
export const __wbindgen_export4: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
