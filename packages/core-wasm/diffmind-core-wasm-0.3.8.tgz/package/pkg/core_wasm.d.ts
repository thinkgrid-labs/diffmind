/* tslint:disable */
/* eslint-disable */

export class ReviewAnalyzer {
    free(): void;
    [Symbol.dispose](): void;
    analyze_diff(diff: string, context: string): string;
    analyze_diff_chunked(diff: string, context: string, _max_tokens_per_chunk: number): string;
    constructor(model_bytes: Uint8Array, tokenizer_bytes: Uint8Array);
}
